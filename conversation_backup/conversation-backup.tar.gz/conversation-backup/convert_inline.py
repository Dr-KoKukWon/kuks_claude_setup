#!/usr/bin/env python3
"""Convert JSONL to readable markdown"""
import sys, json, os, re
from datetime import datetime

temp_file = sys.argv[1]
backup_file = sys.argv[2]
session_id = sys.argv[3]
cwd = sys.argv[4]

with open(temp_file, 'r', encoding='utf-8') as f:
    input_data = f.read()

entries = []
for line in input_data.strip().split('\n'):
    if line.strip().startswith('{'):
        try:
            entries.append(json.loads(line))
        except:
            pass

# Check if file exists to append
existing_content = ""
if os.path.exists(backup_file):
    with open(backup_file, 'r', encoding='utf-8') as f:
        existing_content = f.read()

out = []

# If file doesn't exist, create header
if not existing_content:
    out = [
        "# Conversation Backup",
        "",
        f"**Session:** {session_id}",
        f"**Time:** {datetime.now().isoformat()}",
        f"**Directory:** {cwd}",
        "",
        "---",
        ""
    ]
else:
    # Append mode: add continuation marker
    out = [
        "",
        "---",
        "",
        f"### Compact: {datetime.now().isoformat()}",
        "",
        "---",
        ""
    ]

for entry in entries:
    t = entry.get("type", "")
    if t in ("progress", "hook_progress"):
        continue

    if t == "user":
        msg = entry.get("message", {})
        content = msg.get("content", "") or entry.get("content", "")
        if isinstance(content, str) and content.strip():
            out.extend(["### User", "", content.strip(), "", "---", ""])
        elif isinstance(content, list):
            for c in content:
                if isinstance(c, dict) and c.get("type") == "text":
                    text = c.get("text", "").strip()
                    if text:
                        out.extend(["### User", "", text, "", "---", ""])
                        break

    elif t == "assistant":
        msg = entry.get("message", {})
        content = msg.get("content", []) or entry.get("content", [])
        if isinstance(content, str) and content.strip():
            out.extend(["### Assistant", "", content.strip(), "", "---", ""])
        elif isinstance(content, list):
            texts = []
            tools = []
            for c in content:
                if isinstance(c, dict):
                    if c.get("type") == "text":
                        txt = c.get("text", "").strip()
                        if txt:
                            texts.append(txt)
                    elif c.get("type") == "tool_use":
                        tools.append(c.get("name", "?"))
            if texts or tools:
                out.append("### Assistant")
                out.append("")
                out.extend(texts)
                if tools:
                    out.append("")
                    tool_str = ", ".join("`" + t + "`" for t in tools)
                    out.append("**Tools:** " + tool_str)
                out.extend(["", "---", ""])

out.append("")
out.append(f"*Saved: {datetime.now().isoformat()}*")

# Append to existing file or create new one
if existing_content:
    with open(backup_file, "a", encoding="utf-8") as f:
        f.write("\n".join(out))
else:
    with open(backup_file, "w", encoding="utf-8") as f:
        f.write("\n".join(out))

print(f"Saved: {backup_file}")
