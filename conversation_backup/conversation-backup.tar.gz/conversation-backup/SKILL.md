---
name: conversation-backup
description: Auto-backup conversation to .conversation/ folder when auto-compact or /compact triggers. Creates readable markdown format directly with User/Assistant messages and tool names.
---

# Conversation Backup

Automatically saves conversation history in **readable markdown format** before context compaction.

## How It Works

This skill uses a `PreCompact` hook that executes before `/compact` or auto-compact:

1. Reads the current transcript
2. Extracts session ID and project directory
3. Converts JSONL to readable markdown
4. Saves to `.conversation/session-{session-id}.md`
5. If file exists, appends new content (same session = same file)

## Output Format

```markdown
# Conversation Backup

**Session:** abc123
**Time:** 2026-02-28T14:00:00
**Directory:** /path/to/project

---

### User

Your message here...

---

### Assistant

Assistant response...

**Tools:** `Read`, `Bash`

---

### Compact: 2026-02-28T15:00:00

---

### User

More messages after compact...

---
```

## Installation

Hook is configured in `~/.claude/settings.json`:

```json
{
  "hooks": {
    "PreCompact": [
      {
        "matcher": "*",
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.claude/skills/conversation-backup/backup.sh",
            "timeout": 30
          }
        ]
      }
    ]
  }
}
```

## Files

```
.conversation/
├── session-abc123.md         # Session abc123 (appends on each compact)
├── session-def456.md         # Session def456
└── ...
```

## Features

- **Same session = same file**: Content is appended when compacting multiple times
- **Readable markdown**: Direct format, no conversion needed
- **Auto cleanup**: Keeps last 100 files
- **Session tracking**: Each session has its own file

## Manual Backup

```bash
# Pipe JSONL data to backup script
cat transcript.jsonl | bash ~/.claude/skills/conversation-backup/backup.sh
```

## Configuration

- `CONVERSATION_BACKUP_DIR`: Custom backup directory (default: `{project}/.conversation`)
- `CONVERSATION_BACKUP_MAX_FILES`: Max files to keep (default: 100)

## Notes

- Creates readable markdown directly (no separate conversion needed)
- Old backups auto-cleaned (keeps last 100)
- Requires Claude Code restart after hook configuration
