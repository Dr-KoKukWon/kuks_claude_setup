#!/usr/bin/env python3
"""
Convert JSONL backup to readable markdown.
Usage: python3 convert.py <backup.md>
"""
import sys
import json
import re
from pathlib import Path

def convert_file(input_path):
    content = Path(input_path).read_text(encoding='utf-8')

    # Try to extract JSONL from code block first
    match = re.search(r'```jsonl\n(.+?)\n```', content, re.DOTALL)
    if match:
        jsonl = match.group(1)
    else:
        # Try to extract raw JSONL (lines starting with {)
        lines = content.split('\n')
        jsonl_lines = [l for l in lines if l.strip().startswith('{')]
        jsonl = '\n'.join(jsonl_lines)

    if not jsonl.strip():
        print("No JSONL found in file")
        return

    entries = []
    for line in jsonl.strip().split('\n'):
        if line.strip():
            try:
                entries.append(json.loads(line))
            except:
                continue

    if not entries:
        print("No valid JSON entries found")
        return

    # Build readable output
    session_id = entries[0].get('sessionId', 'unknown') if entries else 'unknown'

    out = [
        "# Conversation (Readable)",
        "",
        f"**Session:** {session_id}",
        f"**Source:** {input_path}",
        "",
        "---",
        ""
    ]

    for entry in entries:
        t = entry.get("type", "")

        if t in ("progress", "hook_progress"):
            continue

        if t == "user":
            msg = entry.get("message", {})
            content = msg.get("content", "") or entry.get("content", "")

            if isinstance(content, str) and content.strip():
                out.extend(["### 👤 User", "", content.strip(), "", "---", ""])
            elif isinstance(content, list):
                for c in content:
                    if isinstance(c, dict) and c.get("type") == "text":
                        text = c.get("text", "").strip()
                        if text:
                            out.extend(["### 👤 User", "", text, "", "---", ""])
                            break  # Only first text

        elif t == "assistant":
            msg = entry.get("message", {})
            content = msg.get("content", []) or entry.get("content", [])

            if isinstance(content, str) and content.strip():
                out.extend(["### 🤖 Assistant", "", content.strip(), "", "---", ""])
            elif isinstance(content, list):
                texts = []
                tools = []
                for c in content:
                    if isinstance(c, dict):
                        if c.get("type") == "text":
                            txt = c.get("text", "").strip()
                            if txt:
                                texts.append(txt)
                        elif c.get("type") == "tool_use":
                            tools.append(c.get("name", "?"))

                if texts or tools:
                    out.append("### 🤖 Assistant")
                    out.append("")
                    out.extend(texts)
                    if tools:
                        out.append("")
                        out.append("**Tools:** " + ", ".join(f"`{t}`" for t in tools))
                    out.extend(["", "---", ""])

    # Write readable version
    output_path = input_path.replace('.md', '-readable.md')
    Path(output_path).write_text("\n".join(out), encoding='utf-8')
    print(f"✅ Converted to: {output_path}")
    print(f"   Found {len(entries)} entries, {len([e for e in entries if e.get('type') in ('user', 'assistant')])} messages")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 convert.py <backup.md>")
        print("       python3 convert.py .conversation/*.md  # convert all")
        sys.exit(1)
    convert_file(sys.argv[1])
