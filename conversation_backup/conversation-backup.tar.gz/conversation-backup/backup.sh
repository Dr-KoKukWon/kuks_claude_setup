#!/bin/bash
# Conversation Backup - Saves readable markdown before compact
set -euo pipefail

# Save input to temp file first
TEMP_FILE=$(mktemp)
cat > "$TEMP_FILE"

# Extract session_id (try multiple patterns)
SESSION_ID=$(grep -oP '"sessionId"\s*:\s*"\K[^"]+' "$TEMP_FILE" | head -1 || true)
[ -z "$SESSION_ID" ] && SESSION_ID=$(grep -oP '"session_id"\s*:\s*"\K[^"]+' "$TEMP_FILE" | head -1 || true)
[ -z "$SESSION_ID" ] && SESSION_ID="unknown"

# Extract cwd from transcript
PROJECT_CWD=$(grep -oP '"cwd"\s*:\s*"\K[^"]+' "$TEMP_FILE" | head -1 || true)
[ -z "$PROJECT_CWD" ] && PROJECT_CWD="."

# Use project cwd for backup directory (not current working directory)
BACKUP_DIR="${PROJECT_CWD}/.conversation"
mkdir -p "$BACKUP_DIR"

# Use session-based filename (no timestamp) for appending
BACKUP_FILE="${BACKUP_DIR}/session-${SESSION_ID}.md"

# Convert to readable format using Python
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "${SCRIPT_DIR}/convert_inline.py" "$TEMP_FILE" "$BACKUP_FILE" "$SESSION_ID" "$PROJECT_CWD"

rm -f "$TEMP_FILE"

# Cleanup old files (keep last 100)
cd "$BACKUP_DIR"
ls -t session-*.md 2>/dev/null | tail -n +101 | xargs -r rm -f
